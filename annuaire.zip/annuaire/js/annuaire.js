function fermerFenetre(cible) {
    $(cible).hide();
}


/** je declare la fonction getFichierJSON() */

function getFichierJSON() {

    /** je vide le contenu du #tAnnuaire*/
    $("#tAnnuaire").html("");
    /** grace a la fonction $.get() du jQuery je vais chercher le fichier annuaire.json et j'alimente la variable data   */
    $.get('data/annuaire.json', function(data) {
        // je decrale une variabel num = 0;
        var num = 0;
        /*
        for (i = 0; i < data.length; i++) {
            num++;
            // l'alimente #tAnnuaire par les donnees du fichier JSON  
            $("#tAnnuaire").append("<tr><td>" + i + "</td><td>" + data[i].prenom + "</td><td> " + data[i].nom + "</td><td> " + data[i].tel + "</td><td> " + data[i].email + "</td><td><button class='supp' value='" + data[i].email + "' >S</button></td></tr>");

        }
         */
        /** je fait une boucle $.each() sue la valeur du data */
        console.log(data);
        $.each(data, function(key, val) {
            // ancrementation de la variable num par 1
            num++;
            //l'alimente #tAnnuaire par les donnees du fichier JSON  
            // $("#tAnnuaire").prepend("<tr><td>" + num + "</td><td>" + val.prenom + "</td><td> " + val.nom + "</td><td> " + val.tel + "</td><td> " + val.email + "</td><td><button class='supp' value='" + val.email + "' >S</button></td></tr>");
            $("#tAnnuaire").append("<tr><td>" + num + "</td><td>" + val.prenom + "</td><td> " + val.nom + "</td><td> " + val.tel + "</td><td> " + val.email + "</td><td><button class='supp' value='" + val.email + "' >S</button></td></tr>");
        });

    });
}

function getUrl(selecteur, attribut, cible) {
    $(selecteur).on("click", function() {
        var url = $(this).attr(attribut);
        $.get(url)
            .done(function(data) {
                $(cible).html(data); //set
            })
            .fail(function(data) {
                $(cible).html("<h1>le fichier n'existe pas!</h1>"); //set
            });
    });
}

function ouvrirFenetre(selecteur, fichier, cible) {
    $(selecteur).on("click", function() {
        //je recupere le fichier formAjout.html 
        $.get(fichier, function(data) {
            $(cible).show();
            $(cible).html(data);
        });
    });
}

function cacher(selecteur, cible) {
    $(selecteur).on("click", function() {
        $(cible).hide();
    });
}

function rechercher(selecteur, cible, getValue = null) {

    if (getValue == null) {
        $(selecteur).on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $(cible).filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    } else {
        $(selecteur).on("click", function() {
            var value = $(getValue).val().toLowerCase();
            $(cible).filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    }


}
/*

//document.forms["nomDuFormulaire"]['nom'].value; //js
//$("nom").val(); //jquery


document.querySelector(".fenetre").style.display = "none"; // javascript
$(".fenetre").hide(); // jquery

document.querySelector(".fenetre").style.display = "block";
$(".fenetre").show();

document.querySelector("p").innerHTML; // javascript GET
$("p").html(); // jquery GET

document.querySelector("p").innerHTML = "hello"; // javascript SET
$("p").html("hello"); // jquery SET


document.querySelector("p").innerHTML = ""; // javascript SET vide
$("p").html(""); // jquery SET vide
*/